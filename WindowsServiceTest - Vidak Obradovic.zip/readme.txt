NuGet references:
-Topshelf
-System.Data.SQLight
-Dapper
-CsvHelper

Interval in which CPU, DISK and MEMORY utilization retrieved is configurable in App.config. It is set at 5min

Ids in both tables are AUTOINCREMENT. I wanted to create id for hardware info as hashed value of combination of Model and Serial Number, but I wouldn't have made it on time. That way would each row unique. For the first table I wanted to use conbination of hardwareType and time, also hashed.

In the lack of time I did not menaged to write unit tests. If it is possible I can do that afterwards.

I wrote program as a console aplication for easier running and debugging.





