﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsServiceTest
{
    public class SystemUsage
    {
        public static double GetCpuUsage()
        {
            var cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
            cpuCounter.NextValue();
            System.Threading.Thread.Sleep(1000);
            return cpuCounter.NextValue();
        }

        public static double GetMemoryUsage()
        {
            var ramCounter = new PerformanceCounter("Memory", "% Committed Bytes In Use");
            return ramCounter.NextValue();
        }

        public static double GetDiskUsage()
        {
            DriveInfo drive = new DriveInfo("C");

            if (drive.IsReady)
            {
                double percentFree = 100.0 * drive.TotalFreeSpace / drive.TotalSize;
                double percentUsed = 100.0 - percentFree;
                return percentUsed;
            }

            throw new Exception("Drive C: is not ready or does not exist.");
        }

    }
}
