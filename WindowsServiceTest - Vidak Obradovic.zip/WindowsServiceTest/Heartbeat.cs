﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace WindowsServiceTest
{
    class Heartbeat
    {
        private readonly Timer _timer;

        public Heartbeat()
        {
            //interval in milisecond using configuration parameter expressed in minutes
            double interval = double.Parse(ConfigurationManager.AppSettings["IntervalMinutes"]) * 1000 * 60; 
            _timer = new Timer(interval) { AutoReset = true };
            _timer.Elapsed += timer_Elapsed;
        }
        
        private void timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            // Get system usage data
            double cpuUsage = SystemUsage.GetCpuUsage();
            double memoryUsage = SystemUsage.GetMemoryUsage();
            double diskUsage = SystemUsage.GetDiskUsage();

            SqliteDataAccess.SaveUsage("1", (int)Math.Round(cpuUsage));
            SqliteDataAccess.SaveUsage("2", (int)Math.Round(memoryUsage));
            SqliteDataAccess.SaveUsage("3", (int)Math.Round(diskUsage));
        }


        public void Start()
        {
            _timer.Start();
        }

        public void Stop()
        {
            //SqliteDataAccess.CreateReport();
            _timer.Stop();
        }
    }
}
