﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.IO;
using System.Globalization;
using CsvHelper;

namespace WindowsServiceTest
{
    public class SqliteDataAccess
    {
        public static void SaveUsage(string hardwareType, double usage)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                cnn.Execute("insert into Records (hardwareType, Value) values (@HardwareType, @Value)", new { HardwareType = hardwareType, Value = usage });
            }
        }

        public static void CreateReport()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var data = cnn.Query("SELECT r.Value, r.CreateDate, h.Model, h.AdditionalInfo FROM Records r INNER JOIN HardwareTypes h ON r.hardwareType = h.Id");

                using (var writer = new StreamWriter("report.csv"))
                using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
                {
                    csv.WriteRecords(data);
                }
            }
        }

        private static string LoadConnectionString(string id = "Default")
        {
            return ConfigurationManager.ConnectionStrings[id].ConnectionString;
        }

    }
}
